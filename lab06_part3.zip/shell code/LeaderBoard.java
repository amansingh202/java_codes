import java.io.*;
import java.util.*;

public class LeaderBoard {